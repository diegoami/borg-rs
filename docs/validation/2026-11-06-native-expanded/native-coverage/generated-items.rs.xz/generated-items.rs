pub mod cave_h {pub type C2RustUnnamedH_18=u32;} pub mod monster_h {pub type C2RustUnnamedH_29=u32; pub type C2RustUnnamedH_30=u32;} pub mod borg_item_h {#[allow(non_camel_case_types)] pub struct borg_item {pub desc:Vec<i8>,pub dd:u8,pub ds:u8,pub to_d:i16,pub to_h:i16,pub tval:u8,pub iqty:u8}}
#[path = "/home/diego/projects/borg-rs/borg-rs/src/headers/list_terrain_h.rs"] pub mod terrain;
#[path = "/home/diego/projects/borg-rs/borg-rs/src/borg_headers/borg_trait_h.rs"] pub mod traits;
#[path = "/home/diego/projects/borg-rs/borg-rs/src/headers/list_mon_race_flags_h.rs"] pub mod race_flags;
use race_flags::RF_PASS_WALL;
#[path = "/home/diego/projects/borg-rs/borg-rs/src/headers/list_mon_spells_h.rs"] pub mod spell_flags;
pub mod cave { use super::*;
pub const DUNGEON_WID: i32 = 198;
pub const DUNGEON_HGT: i32 = 66;
pub const AUTO_MAX_X: i32 = DUNGEON_WID;
pub const AUTO_MAX_Y: i32 = DUNGEON_HGT;
#[repr(C)] #[derive(Clone,Copy,Default,Debug,PartialEq,Eq)]
pub struct BorgGrid {
    pub feat: u8,
    pub info: u16,
    pub trap: bool,
    pub glyph: bool,
    pub web: bool,
    pub store: u8,
    pub take: u8,
    pub kill: u8,
    pub xtra: u8,
}
#[derive(Default)]
pub struct CaveState {
    grids: Vec<BorgGrid>,
}
impl CaveState {
    fn index(x: i32, y: i32) -> usize {
        assert!((0..AUTO_MAX_X).contains(&x) && (0..AUTO_MAX_Y).contains(&y));
        (y * AUTO_MAX_X + x) as usize
    }

    /// The grid at (x, y) (`borg_grids[y][x]`).
    pub fn grid(&self, x: i32, y: i32) -> &BorgGrid {
        &self.grids[Self::index(x, y)]
    }

    /// The grid at (x, y), mutable.
    pub fn grid_mut(&mut self, x: i32, y: i32) -> &mut BorgGrid {
        &mut self.grids[Self::index(x, y)]
    }

    /// Row `y` (`borg_grids[y]`).
    pub fn row_mut(&mut self, y: i32) -> &mut [BorgGrid] {
        let start = Self::index(0, y);
        &mut self.grids[start..start + AUTO_MAX_X as usize]
    }
}
pub fn allocated()->CaveState { CaveState{grids:vec![BorgGrid::default();(AUTO_MAX_X*AUTO_MAX_Y) as usize]} }
}
pub mod cave_util {use super::*; use cave::BorgGrid; use terrain::*;
fn feat_is(g: &BorgGrid, feats: &[u32]) -> bool {
    feats.contains(&u32::from(g.feat))
}
pub fn borg_cave_floor_bold(st: &BorgState, y: i32, x: i32) -> bool {
    if engine::square_in_bounds_fully(x, y) {
        let g = st.cave.grid(x, y);
        if u32::from(g.feat) == FEAT_FLOOR
            || g.trap
            || feat_is(g, &[FEAT_LESS, FEAT_MORE, FEAT_BROKEN, FEAT_PASS_RUBBLE, FEAT_OPEN])
        {
            return true;
        }
    }
    false
}
pub fn borg_cave_floor_grid(ag: &BorgGrid) -> bool {
    feat_is(
        ag,
        &[
            FEAT_NONE,
            FEAT_FLOOR,
            FEAT_OPEN,
            FEAT_MORE,
            FEAT_LESS,
            FEAT_BROKEN,
            FEAT_PASS_RUBBLE,
            FEAT_LAVA,
        ],
    )
}
pub fn borg_feature_protected(ag: &BorgGrid) -> bool {
    let f = u32::from(ag.feat);
    ag.glyph || ag.kill != 0 || (FEAT_CLOSED..=FEAT_PERM).contains(&f)
}
}
use cave_util::{borg_cave_floor_bold,borg_cave_floor_grid};
pub mod projection { use super::*; use cave::BorgGrid; use terrain::*; use traits::*;
#[derive(Default)] pub struct ProjectionState {pub target_loc:loc}
fn feat_is(g: &BorgGrid, feat: u32) -> bool {
    u32::from(g.feat) == feat
}
fn los_with(
    y1: i32,
    x1: i32,
    y2: i32,
    x2: i32,
    origin_ok: impl FnOnce() -> bool,
    floor: impl Fn(i32, i32) -> bool,
) -> bool {
    /* Extract the offset */
    let dy = y2 - y1;
    let dx = x2 - x1;

    /* Extract the absolute offset */
    let ay = dy.abs();
    let ax = dx.abs();

    /* Handle adjacent (or identical) grids */
    if ax < 2 && ay < 2 {
        return true;
    }

    /* Paranoia -- require "safe" origin */
    if !origin_ok() {
        return false;
    }

    /* Directly South/North */
    if dx == 0 {
        if dy > 0 {
            /* South -- check for walls */
            let mut ty = y1 + 1;
            while ty < y2 {
                if !floor(ty, x1) {
                    return false;
                }
                ty += 1;
            }
        } else {
            /* North -- check for walls */
            let mut ty = y1 - 1;
            while ty > y2 {
                if !floor(ty, x1) {
                    return false;
                }
                ty -= 1;
            }
        }

        /* Assume los */
        return true;
    }

    /* Directly East/West */
    if dy == 0 {
        if dx > 0 {
            /* East -- check for walls */
            let mut tx = x1 + 1;
            while tx < x2 {
                if !floor(y1, tx) {
                    return false;
                }
                tx += 1;
            }
        } else {
            /* West -- check for walls */
            let mut tx = x1 - 1;
            while tx > x2 {
                if !floor(y1, tx) {
                    return false;
                }
                tx -= 1;
            }
        }

        /* Assume los */
        return true;
    }

    /* Extract some signs */
    let sx = if dx < 0 { -1 } else { 1 };
    let sy = if dy < 0 { -1 } else { 1 };

    if ax == 1 {
        /* Vertical "knights" */
        if ay == 2 && floor(y1 + sy, x1) {
            return true;
        }
    } else if ay == 1 {
        /* Horizontal "knights" */
        if ax == 2 && floor(y1, x1 + sx) {
            return true;
        }
    }

    /* Calculate scale factor div 2 */
    let f2 = ax * ay;

    /* Calculate scale factor */
    let f1 = f2 << 1;

    if ax >= ay {
        /* Travel horizontally */

        /* Let m = dy / dx * 2 * (dy * dx) = 2 * dy * dy */
        let mut qy = ay * ay;
        let m = qy << 1;

        let mut tx = x1 + sx;
        let mut ty;

        /* Consider the special case where slope == 1. */
        if qy == f2 {
            ty = y1 + sy;
            qy -= f1;
        } else {
            ty = y1;
        }

        /* Note (below) the case (qy == f2), where */
        /* the LOS exactly meets the corner of a tile. */
        while x2 - tx != 0 {
            if !floor(ty, tx) {
                return false;
            }

            qy += m;

            if qy < f2 {
                tx += sx;
            } else if qy > f2 {
                ty += sy;
                if !floor(ty, tx) {
                    return false;
                }
                qy -= f1;
                tx += sx;
            } else {
                ty += sy;
                qy -= f1;
                tx += sx;
            }
        }
    } else {
        /* Travel vertically */

        /* Let m = dx / dy * 2 * (dx * dy) = 2 * dx * dx */
        let mut qx = ax * ax;
        let m = qx << 1;

        let mut ty = y1 + sy;
        let mut tx;

        if qx == f2 {
            tx = x1 + sx;
            qx -= f1;
        } else {
            tx = x1;
        }

        /* Note (below) the case (qx == f2), where */
        /* the LOS exactly meets the corner of a tile. */
        while y2 - ty != 0 {
            if !floor(ty, tx) {
                return false;
            }

            qx += m;

            if qx < f2 {
                ty += sy;
            } else if qx > f2 {
                tx += sx;
                if !floor(ty, tx) {
                    return false;
                }
                qx -= f1;
                ty += sy;
            } else {
                tx += sx;
                qx -= f1;
                ty += sy;
            }
        }
    }

    /* Assume los */
    true
}
pub fn borg_los(st: &BorgState, y1: i32, x1: i32, y2: i32, x2: i32) -> bool {
    los_with(
        y1,
        x1,
        y2,
        x2,
        || engine::square_in_bounds_fully(x1, y1),
        |y, x| borg_cave_floor_bold(st, y, x),
    )
}
fn max_range() -> i32 {
    i32::from(engine::z_info().max_range)
}
fn fear_region_scary(st: &mut BorgState) -> bool {
    let (cy, cx) = (st.borg.c.y, st.borg.c.x);
    i32::from(st.danger.fear_region[(cy / 11) as usize][(cx / 11) as usize]) >= i32::from(st.borg.avoidance) / 20
}
pub fn borg_projectable(st: &mut BorgState, y1: i32, x1: i32, y2: i32, x2: i32) -> bool {
    /* Start at the initial location */
    let mut y = y1;
    let mut x = x1;

    /* Simulate the spell/missile path */
    let mut dist = 0;
    while dist <= max_range() {
        /* Get the grid */
        let ag = *st.cave.grid(x, y);

        if st.borg.tr(BI_CURHP) < st.borg.tr(BI_MAXHP) / 3
            || st.borg.morgoth_position
            || st.borg.mon.scary
        {
            /* Assume all unknown grids more than distance 20 from you
             * are walls--when I am wounded. This will make me more fearful
             * of the grids that are up to 19 spaces away.  I treat them as
             * regular floor grids.  Which means monsters are assumed to have
             * LOS on me.  I am also more likely to shoot into the dark grids.
             */
            if dist > 20 && feat_is(&ag, FEAT_NONE) {
                break;
            }
        } else if st.borg.tr(BI_CURHP) < st.borg.tr(BI_MAXHP) / 2 {
            /* Assume all unknow grids more than distance 10 from you
             * are walls--when I am wounded. This will make me more fearful
             * of the grids that are up to 9 spaces away.  I treat them as
             * regular floor grids.
             */
            if dist > 10 && feat_is(&ag, FEAT_NONE) {
                break;
            }
        } else if fear_region_scary(st) {
            /* If a non-LOS monster is attacking me, then it is probably has
             * LOS to me, so do not place walls on unknown grids.  This will
             * allow me the chance to attack monsters.
             *
             * This does not work if the non-LOS monster is invisible.
             * This helps in a case like this:
             *####################          1.  Player has ESP and can sense the
             *                                  priest.
             *......@......      p          2.  Priest has cast a spell at the
             *                                  player.
             *#############                 3.  Unknown grids are between player
             *                                  and priest
             *                              4.  Borg has created regional fear
             *                                  from non-LOS priest.
             */
            if dist > max_range() && feat_is(&ag, FEAT_NONE) {
                break;
            }
        } else {
            /* Assume all unknow grids more than distance 3 from you
             * are walls.  This makes me brave and chancey.
             */
            if dist > 2 && feat_is(&ag, FEAT_NONE) {
                break;
            }
        }
        /* Never pass through walls/doors */
        if dist != 0 && !borg_cave_floor_grid(&ag) {
            break;
        }

        /* Check for arrival at "final target" */
        if x == x2 && y == y2 {
            return true;
        }

        /* Calculate the new location */
        borg_inc_motion(&mut y, &mut x, y1, x1, y2, x2);
        dist += 1;
    }

    /* Assume obstruction */
    false
}
pub fn borg_offset_projectable(st: &BorgState, y1: i32, x1: i32, y2: i32, x2: i32) -> bool {
    /* Start at the initial location */
    let mut y = y1;
    let mut x = x1;

    /* Simulate the spell/missile path */
    let mut dist = 0;
    while dist <= max_range() {
        /* Get the grid */
        let ag = st.cave.grid(x, y);

        /* Assume all unknown grids are walls. */
        if dist != 0 && feat_is(ag, FEAT_NONE) {
            break;
        }

        /* Never pass through rubble */
        if feat_is(ag, FEAT_PASS_RUBBLE) {
            break;
        }

        /* Never pass through walls/doors */
        if dist != 0 && !borg_cave_floor_grid(ag) {
            break;
        }

        /* Check for arrival at "final target" */
        if x == x2 && y == y2 {
            return true;
        }

        /* Calculate the new location */
        borg_inc_motion(&mut y, &mut x, y1, x1, y2, x2);
        dist += 1;
    }

    /* Assume obstruction */
    false
}
pub fn borg_projectable_pure(st: &BorgState, y1: i32, x1: i32, y2: i32, x2: i32) -> bool {
    /* Start at the initial location */
    let mut y = y1;
    let mut x = x1;

    /* Simulate the spell/missile path */
    let mut dist = 0;
    while dist <= max_range() {
        /* Get the grid */
        let ag = st.cave.grid(x, y);

        /* Assume unknown grids are walls */
        if dist != 0 && feat_is(ag, FEAT_NONE) {
            break;
        }

        /* Never pass through walls/doors */
        if dist != 0 && !borg_cave_floor_grid(ag) {
            break;
        }

        /* Check for arrival at "final target" */
        if x == x2 && y == y2 {
            return true;
        }

        /* Stop at monsters */
        if ag.kill != 0 {
            break;
        }

        /* Calculate the new location */
        borg_inc_motion(&mut y, &mut x, y1, x1, y2, x2);
        dist += 1;
    }

    /* Assume obstruction */
    false
}
pub fn borg_projectable_dark(st: &BorgState, y1: i32, x1: i32, y2: i32, x2: i32) -> bool {
    let mut unknown = 0;

    /* Start at the initial location */
    let mut y = y1;
    let mut x = x1;

    /* Simulate the spell/missile path */
    let mut dist = 0;
    while dist <= max_range() {
        /* Get the grid */
        let ag = st.cave.grid(x, y);

        /* We want at least 1 unknown grid */
        if dist != 0 && feat_is(ag, FEAT_NONE) {
            unknown += 1;
        }

        /* Never pass through walls/doors */
        if dist != 0 && !borg_cave_floor_grid(ag) {
            break;
        }

        /* Check for arrival at "final target" */
        if x == x2 && y == y2 && unknown >= 1 {
            return true;
        }

        /* Stop at monsters */
        if ag.kill != 0 {
            break;
        }

        /* Calculate the new location */
        borg_inc_motion(&mut y, &mut x, y1, x1, y2, x2);
        dist += 1;
    }

    /* Assume obstruction */
    false
}
pub fn borg_inc_motion(py: &mut i32, px: &mut i32, y1: i32, x1: i32, y2: i32, x2: i32) {
    /* Extract the distance travelled */
    /* Analyze "dy" */
    let (dy, sy) = if y2 < y1 { (y1 - y2, -1) } else { (y2 - y1, 1) };

    /* Analyze "dx" */
    let (dx, sx) = if x2 < x1 { (x1 - x2, -1) } else { (x2 - x1, 1) };

    /* Paranoia -- no motion */
    if dy == 0 && dx == 0 {
        return;
    }

    /* Number of "units" in one "half" grid */
    let half = dy * dx;

    /* Number of "units" in one "full" grid */
    let full = half << 1;

    /* First step is fixed */
    if *px == x1 && *py == y1 {
        if dy > dx {
            *py += sy;
        } else if dx > dy {
            *px += sx;
        } else {
            *px += sx;
            *py += sy;
        }
        return;
    }

    if dy > dx {
        /* Move mostly vertically */
        let mut k = dy;

        /* Start at tile edge */
        let mut frac = dx * dx;

        /* Let m = ((dx/dy) * full) = (dx * dx * 2) = (frac * 2) */
        let m = frac << 1;

        /* Start */
        let mut y = y1 + sy;
        let mut x = x1;

        /* Create the projection path */
        loop {
            if x == *px && y == *py {
                k = 1;
            }

            /* Slant */
            if m != 0 {
                /* Advance (X) part 1 */
                frac += m;

                /* Horizontal change */
                if frac >= half {
                    /* Advance (X) part 2 */
                    x += sx;

                    /* Advance (X) part 3 */
                    frac -= full;
                }
            }

            /* Advance (Y) */
            y += sy;

            /* Track distance */
            k -= 1;

            if k == 0 {
                *px = x;
                *py = y;
                return;
            }
        }
    } else if dx > dy {
        /* Move mostly horizontally */

        /* Start at tile edge */
        let mut frac = dy * dy;

        /* Let m = ((dy/dx) * full) = (dy * dy * 2) = (frac * 2) */
        let m = frac << 1;

        /* Start */
        let mut y = y1;
        let mut x = x1 + sx;
        let mut k = dx;

        /* Create the projection path */
        loop {
            if x == *px && y == *py {
                k = 1;
            }

            /* Slant */
            if m != 0 {
                /* Advance (Y) part 1 */
                frac += m;

                /* Vertical change */
                if frac >= half {
                    /* Advance (Y) part 2 */
                    y += sy;

                    /* Advance (Y) part 3 */
                    frac -= full;
                }
            }

            /* Advance (X) */
            x += sx;

            /* Track distance */
            k -= 1;

            if k == 0 {
                *px = x;
                *py = y;
                return;
            }
        }
    } else {
        /* Diagonal */

        /* Start */
        let mut k = dy;
        let mut y = y1 + sy;
        let mut x = x1 + sx;

        /* Create the projection path */
        loop {
            if x == *px && y == *py {
                k = 1;
            }

            /* Advance (Y) */
            y += sy;

            /* Advance (X) */
            x += sx;

            /* Track distance */
            k -= 1;

            if k == 0 {
                *px = x;
                *py = y;
                return;
            }
        }
    }
}
pub fn borg_distance(y: i32, x: i32, y2: i32, x2: i32) -> i32 {
    engine::distance(loc { x, y }, loc { x: x2, y: y2 })
}
pub fn borg_target(st: &mut BorgState, t: loc, require_monster: bool) -> bool {
    let kill_idx = st.cave.grid(t.x, t.y).kill;

    /* Log */
    /* Report a little bit */
    if kill_idx != 0 {
        let kill = st.kills.kills[usize::from(kill_idx)];
        let mut msg = b"# Targeting ".to_vec();
        msg.extend_from_slice(crate::borg_flow_kill::borg_race_name(i32::from(kill.r_idx)).to_bytes());
        msg.extend_from_slice(
            format!(" who has {} Hit Points ({},{}).", kill.power, t.y, t.x).as_bytes(),
        );
        borg_note_bytes(st, &msg);
    } else {
        borg_note(st, &format!("# Targeting location ({},{})", t.y, t.x));
    }

    /* Target mode */
    borg_keypress(st, u32::from(b'*'));

    /* Target a location */
    borg_keypress(st, u32::from(b'p'));

    /* Determine "path" */
    let mut x1 = st.borg.c.x;
    let mut y1 = st.borg.c.y;
    let x2 = t.x;
    let y2 = t.y;

    /* Move to the location (diagonals) */
    while y1 < y2 && x1 < x2 {
        borg_keypress(st, u32::from(b'3'));
        y1 += 1;
        x1 += 1;
    }
    while y1 < y2 && x1 > x2 {
        borg_keypress(st, u32::from(b'1'));
        y1 += 1;
        x1 -= 1;
    }
    while y1 > y2 && x1 < x2 {
        borg_keypress(st, u32::from(b'9'));
        y1 -= 1;
        x1 += 1;
    }
    while y1 > y2 && x1 > x2 {
        borg_keypress(st, u32::from(b'7'));
        y1 -= 1;
        x1 -= 1;
    }

    /* Move to the location */
    while y1 < y2 {
        borg_keypress(st, u32::from(b'2'));
        y1 += 1;
    }
    while y1 > y2 {
        borg_keypress(st, u32::from(b'8'));
        y1 -= 1;
    }
    while x1 < x2 {
        borg_keypress(st, u32::from(b'6'));
        x1 += 1;
    }
    while x1 > x2 {
        borg_keypress(st, u32::from(b'4'));
        x1 -= 1;
    }

    if require_monster {
        borg_keypress(st, u32::from(b'm'));
    }

    /* Select the target */
    borg_keypress(st, u32::from(b'5'));

    /* Carry these variables to be used on reporting spell
     * pathway
     */
    st.projection.target_loc.y = t.y;
    st.projection.target_loc.x = t.x;

    /* Success */
    true
}
fn is_floor(st: &BorgState, x: i32, y: i32) -> bool {
    feat_is(st.cave.grid(x, y), FEAT_FLOOR)
}
pub fn borg_target_unknown_wall(st: &mut BorgState, y: i32, x: i32) -> bool {
    let mut y_hall = false;
    let mut x_hall = false;

    borg_note(st, &format!("# Perhaps wall near targetted location ({},{})", y, x));

    /* Determine "path" */
    let (cy, cx) = (st.borg.c.y, st.borg.c.x);
    let mut n_x = cx;
    let mut n_y = cy;

    /* check for 'in a hall' x axis */
    /* This check is for this: */
    /*
     *      x        x
     *    ..@.  or  .@..
     *      x        x
     *
     * 'x' being 'not a floor' and '.' being a floor.
     *
     * We would like to know if in a hall so we can place
     * the suspect wall off the hallway path.
     * like this:######x  P
     * ........@....
     * ##################
     * The shot may miss and we want the borg to guess the
     * wall to be at the X instead of first unkown grid which
     * is 3 west and 1 south of the X.
     */

    if (is_floor(st, cx, cy + 1)
        && is_floor(st, cx, cy - 1)
        && (is_floor(st, cx, cy + 2) || is_floor(st, cx, cy - 2)))
        && (!is_floor(st, cx + 1, cy) && !is_floor(st, cx - 1, cy))
    {
        x_hall = true;
    }

    /* check for 'in a hall' y axis.
     * Again, we want to place the suspected wall off our
     * hallway.
     */
    if (is_floor(st, cx + 1, cy)
        && is_floor(st, cx - 1, cy)
        && (is_floor(st, cx + 2, cy) || is_floor(st, cx - 2, cy)))
        && (!is_floor(st, cx, cy + 1) && !is_floor(st, cx, cy - 1))
    {
        y_hall = true;
    }

    loop {
        let kill_idx = st.cave.grid(n_x, n_y).kill;
        let kill = st.kills.kills[usize::from(kill_idx)];

        if engine::race_flag_has(usize::from(kill.r_idx), RF_PASS_WALL) {
            borg_note(
                st,
                &format!(
                    "# Guessing wall ({},{}) under ghostly target ({},{})",
                    n_y, n_x, n_y, n_x
                ),
            );
            st.cave.grid_mut(n_x, n_y).feat = FEAT_GRANITE as u8;
            return true; /* not sure... should we return here? */
        }

        if feat_is(st.cave.grid(n_x, n_y), FEAT_NONE)
            && (n_y != st.borg.c.y || !y_hall)
            && (n_x != st.borg.c.x || !x_hall)
        {
            borg_note(
                st,
                &format!("# Guessing wall ({},{}) near target ({},{})", n_y, n_x, y, x),
            );
            st.cave.grid_mut(n_x, n_y).feat = FEAT_GRANITE as u8;
            return true; /* not sure... should we return here?
                          maybe should mark ALL unknowns in path... */
        }

        /* Pathway found the target. */
        if n_x == x && n_y == y {
            /* end of the pathway */
            let (cy, cx) = (st.borg.c.y, st.borg.c.x);
            borg_inc_motion(&mut n_y, &mut n_x, y, x, cy, cx);
            borg_note(
                st,
                &format!("# Guessing wall ({},{}) near target ({},{})", n_y, n_x, y, x),
            );
            st.cave.grid_mut(n_x, n_y).feat = FEAT_GRANITE as u8;
            return true;
        }

        /* Calculate the new location */
        let (cy, cx) = (st.borg.c.y, st.borg.c.x);
        borg_inc_motion(&mut n_y, &mut n_x, cy, cx, y, x);
    }
}
}
pub mod flow { use super::*; pub fn borg_flow_old(st:&mut BorgState,why:i32)->bool{glyph_callback(st,4,why,0)} use cave::{BorgGrid,AUTO_MAX_X,AUTO_MAX_Y}; use terrain::*; use traits::*;
pub const AUTO_FLOW_MAX: i32 = 1536;
pub const AUTO_TEMP_MAX: usize = 9000;
pub type BorgData = Vec<[u8; AUTO_MAX_X as usize]>;
pub const BORG_DDX_DDD: [i16; 24] =
    [0, 0, 1, -1, 1, -1, 1, -1, 2, 2, 2, -2, -2, -2, -2, -1, 0, 1, 2, -2, -1, 0, 1, 2];
pub const BORG_DDY_DDD: [i16; 24] =
    [1, -1, 0, 0, 1, 1, -1, -1, -1, 0, 1, -1, 0, 1, -2, -2, -2, -2, -2, 2, 2, 2, 2, 2];
pub fn borg_ddxy_ddd(i: usize) -> (i32, i32) {
    (i32::from(BORG_DDX_DDD[i]), i32::from(BORG_DDY_DDD[i]))
}
#[derive(Default)] pub struct StairTrack{pub num:i16,pub size:i16,pub x:Vec<i32>,pub y:Vec<i32>}
pub struct FlowState {
    /// `flow_head`: next free slot of the queue
    pub head: i32,
    /// `flow_tail`: next entry to dequeue
    pub tail: i32,
    /// `borg_flow_n` (never read, in C either)
    #[allow(dead_code)]
    pub n: i16,
    /// `borg_flow_x`: the queue (`AUTO_FLOW_MAX` entries)
    pub flow_x: Vec<u8>,
    /// `borg_flow_y`
    pub flow_y: Vec<u8>,
    /// `borg_data_flow`: current "flow" data
    pub data_flow: BorgData,
    /// `borg_data_cost`: current "cost" data
    pub data_cost: BorgData,
    /// `borg_data_hard`: constant "hard" data (all 255)
    pub data_hard: BorgData,
    /// `borg_data_know`: current "know" flags
    pub data_know: BorgData,
    /// `borg_data_icky`: current "icky" flags
    pub data_icky: BorgData,
    /// `borg_temp_n`: entries in use in the temporary grid list
    pub temp_n: i16,
    /// `borg_temp_x` (`AUTO_TEMP_MAX` entries)
    pub temp_x: Vec<u8>,
    /// `borg_temp_y`
    pub temp_y: Vec<u8>,
    /// `track_step`: the Borg's steps
    pub track_step: StairTrack,
    /// `track_door`: doors the Borg closed
    pub track_door: StairTrack,
    /// `track_closed`: doors that started closed
    pub track_closed: StairTrack,
}
impl Default for FlowState {
    /// The C statics: zeroed fixed arrays, `NULL` grid maps, empty tracks.
    fn default() -> Self {
        FlowState {
            head: 0,
            tail: 0,
            n: 0,
            flow_x: vec![0; AUTO_FLOW_MAX as usize],
            flow_y: vec![0; AUTO_FLOW_MAX as usize],
            data_flow: Vec::new(),
            data_cost: Vec::new(),
            data_hard: Vec::new(),
            data_know: Vec::new(),
            data_icky: Vec::new(),
            temp_n: 0,
            temp_x: vec![0; AUTO_TEMP_MAX],
            temp_y: vec![0; AUTO_TEMP_MAX],
            track_step: StairTrack::default(),
            track_door: StairTrack::default(),
            track_closed: StairTrack::default(),
        }
    }
}
impl FlowState {
    /// `borg_data_cost->data[y][x]`.
    pub fn cost_at(&self, y: i32, x: i32) -> u8 {
        self.data_cost[y as usize][x as usize]
    }

    /// `(borg_flow_y[0], borg_flow_x[0])`: the first grid enqueued by the
    /// last flow.
    pub fn first(&self) -> (i32, i32) {
        (i32::from(self.flow_y[0]), i32::from(self.flow_x[0]))
    }

    /// `borg_temp_x[borg_temp_n] = x; borg_temp_y[borg_temp_n] = y;
    /// borg_temp_n++;` (panics past `AUTO_TEMP_MAX`, where C overruns).
    pub fn temp_push(&mut self, y: i32, x: i32) {
        let n = self.temp_n as usize;
        self.temp_x[n] = x as u8;
        self.temp_y[n] = y as u8;
        self.temp_n += 1;
    }

    /// `(borg_temp_y[i], borg_temp_x[i])`.
    pub fn temp_at(&self, i: usize) -> (i32, i32) {
        (i32::from(self.temp_y[i]), i32::from(self.temp_x[i]))
    }

    /// Enqueue (x, y) at the head of the circular queue (overflow drops the
    /// entry, as in C).
    fn enqueue(&mut self, y: i32, x: i32) {
        /* Enqueue that entry */
        self.flow_x[self.head as usize] = x as u8;
        self.flow_y[self.head as usize] = y as u8;

        /* Circular queue -- memorize head */
        let old_head = self.head;

        /* Circular queue -- insert with wrap */
        self.head += 1;
        if self.head == AUTO_FLOW_MAX {
            self.head = 0;
        }

        /* Circular queue -- handle overflow (badly) */
        if self.head == self.tail {
            self.head = old_head;
        }
    }
}
pub fn copy_data(dst: &mut BorgData, src: &BorgData) {
    assert!(!dst.is_empty() && !src.is_empty(), "borg_data not allocated");
    dst.copy_from_slice(src);
}
pub fn zero_data(d: &mut BorgData) {
    assert!(!d.is_empty(), "borg_data not allocated");
    for row in d.iter_mut() {
        row.fill(0);
    }
}
pub fn borg_flow_clear(st: &mut BorgState) {
    let f = &mut st.flow;

    /* Reset the "cost" fields */
    copy_data(&mut f.data_cost, &f.data_hard);

    /* Wipe costs and danger */
    if st.danger.wipe {
        /* Wipe the "know" flags */
        zero_data(&mut f.data_know);

        /* Wipe the "icky" flags */
        zero_data(&mut f.data_icky);

        /* Wipe complete */
        st.danger.wipe = false;
    }

    /* Start over */
    f.head = 0;
    f.tail = 0;
}
fn flow_fear(st: &BorgState) -> i32 {
    let b = &st.borg;
    let avoidance = i32::from(b.avoidance);
    let mut fear = 0;

    /* Increase bravery */
    if b.tr(BI_MAXCLEVEL) == 50 {
        fear = avoidance * 5 / 10;
    }
    if b.tr(BI_MAXCLEVEL) != 50 {
        fear = avoidance * 3 / 10;
    }
    if b.mon.scary {
        fear = avoidance * 2;
    }
    if b.mon.unique != 0 && b.status.vault && b.tr(BI_MAXCLEVEL) == 50 {
        fear = avoidance * 3;
    }
    if b.mon.scary && b.tr(BI_CLEVEL) <= 5 {
        fear = avoidance * 3;
    }
    if b.goal.ignoring {
        fear = avoidance * 5;
    }
    if b.time.now - b.time.level > 5000 {
        fear = avoidance * 25;
    }
    if b.tr(BI_FOOD) == 0 {
        fear = avoidance * 100;
    }

    /* Normal in town */
    if b.tr(BI_CLEVEL) == 0 {
        fear = avoidance * 3 / 10;
    }

    fear
}
fn monster_adjacent(st: &BorgState, x: i32, y: i32) -> bool {
    /* Scan the neighbors */
    for ii in 0..8 {
        /* Neighbor grid */
        let xx = x + i32::from(engine::ddx_ddd(ii));
        let yy = y + i32::from(engine::ddy_ddd(ii));

        /* only on legal grids */
        if !engine::square_in_bounds_fully(xx, yy) {
            continue;
        }

        /* Make sure no monster is on this grid, which is
         * adjacent to the grid on which, I am thinking about
         * stepping.
         */
        if st.cave.grid(xx, yy).kill != 0 {
            return true;
        }
    }
    false
}
fn spread_blocked(
    st: &BorgState,
    ag: &BorgGrid,
    x: i32,
    y: i32,
    avoid: bool,
    tunneling: bool,
    twitchy: bool,
) -> bool {
    let b = &st.borg;
    let feat = u32::from(ag.feat);

    /* Avoid "wall" grids (not doors) unless tunneling*/
    /* HACK depends on FEAT order, kinda evil */
    if !tunneling && (feat >= FEAT_SECRET && feat != FEAT_PASS_RUBBLE && feat != FEAT_LAVA) {
        return true;
    }

    /* Avoid "perma-wall" grids */
    if feat == FEAT_PERM {
        return true;
    }

    /* Avoid "Lava" grids (for now) */
    if feat == FEAT_LAVA && b.tr(BI_IFIRE) == 0 {
        return true;
    }

    /* Avoid unknown grids (if requested or retreating)
     * unless twitchy.  In which case, explore it
     */
    if (avoid || b.status.desperate) && feat == FEAT_NONE && !twitchy {
        return true;
    }

    /* flowing into monsters */
    if ag.kill != 0 {
        /* Avoid if Desperate, lunal */
        if b.status.desperate || b.lunal_mode || b.munchkin_mode {
            return true;
        }

        /* Avoid if afraid */
        if b.tr(BI_ISAFRAID) != 0 {
            return true;
        }

        /* Avoid if low level, unless twitchy */
        if !twitchy && b.tr(BI_FOOD) >= 2 && b.tr(BI_MAXCLEVEL) < 5 {
            return true;
        }
    }

    /* Avoid shop entry points if I am not heading to that shop */
    if b.goal.shop >= 0
        && engine::feat_is_shop(i32::from(ag.feat))
        && i32::from(ag.store) != i32::from(b.goal.shop)
        && y != b.c.y
        && x != b.c.x
    {
        return true;
    }

    /* Avoid Traps if low level-- unless brave */
    if ag.trap && !ag.glyph && !twitchy {
        /* Do not disarm when you could end up dead */
        if b.tr(BI_CURHP) < 60 {
            return true;
        }

        /* Do not disarm when clumsy */
        /* since traps can be physical or magical, gotta check both */
        if b.tr(BI_DISP) < 30 && b.tr(BI_CLEVEL) < 20 {
            return true;
        }
        if b.tr(BI_DISP) < 45 && b.tr(BI_CLEVEL) < 10 {
            return true;
        }
        if b.tr(BI_DISM) < 30 && b.tr(BI_CLEVEL) < 20 {
            return true;
        }
        if b.tr(BI_DISM) < 45 && b.tr(BI_CLEVEL) < 10 {
            return true;
        }

        /* NOTE:  Traps are tough to deal with as a low
         * level character.  If any modifications are made above,
         * then the same changes must be made to borg_flow_direct()
         * and borg_flow_interesting()
         */
    }

    false
}
pub fn borg_flow_spread(
    st: &mut BorgState,
    depth: i32,
    mut optimize: bool,
    avoid: bool,
    tunneling: bool,
    stair_idx: i32,
    sneak: bool,
) {
    let mut o = 0;

    /* Default starting points */
    let mut origin_y = st.borg.c.y;
    let mut origin_x = st.borg.c.x;

    /* Is the borg moving under boosted bravery? */
    let twitchy = i32::from(st.borg.avoidance) > st.borg.tr(BI_CURHP);

    /* Use the closest stair for calculation distance (cost) from the stair to
     * the goal */
    if stair_idx >= 0 && st.borg.tr(BI_CLEVEL) < 15 {
        origin_y = st.stairs.less.y[stair_idx as usize];
        origin_x = st.stairs.less.x[stair_idx as usize];
        optimize = false;
    }

    /* Now process the queue */
    while st.flow.head != st.flow.tail {
        /* Extract the next entry */
        let x1 = i32::from(st.flow.flow_x[st.flow.tail as usize]);
        let y1 = i32::from(st.flow.flow_y[st.flow.tail as usize]);

        /* Circular queue -- dequeue the next entry */
        st.flow.tail += 1;
        if st.flow.tail == AUTO_FLOW_MAX {
            st.flow.tail = 0;
        }

        /* Cost (one per movement grid) */
        let n = i32::from(st.flow.data_cost[y1 as usize][x1 as usize]) + 1;

        /* New depth */
        if n > o {
            /* Optimize (if requested) */
            if optimize && n > i32::from(st.flow.data_cost[origin_y as usize][origin_x as usize]) {
                break;
            }

            /* Limit depth */
            if n > depth {
                break;
            }

            /* Save */
            o = n;
        }

        /* Queue the "children" */
        for i in 0..8 {
            /* Neighbor grid */
            let x = x1 + i32::from(engine::ddx_ddd(i));
            let y = y1 + i32::from(engine::ddy_ddd(i));

            /* only on legal grids */
            if !engine::square_in_bounds_fully(x, y) {
                continue;
            }

            /* Skip "reached" grids */
            if i32::from(st.flow.data_cost[y as usize][x as usize]) <= n {
                continue;
            }

            /* Access the grid */
            let ag = *st.cave.grid(x, y);

            /* The grid I am thinking about is adjacent to a monster */
            if sneak && !st.borg.status.desperate && !twitchy && monster_adjacent(st, x, y) {
                continue;
            }

            if spread_blocked(st, &ag, x, y, avoid, tunneling, twitchy) {
                continue;
            }

            /* Ignore "icky" grids */
            if st.flow.data_icky[y as usize][x as usize] != 0 {
                continue;
            }

            /* Analyze every grid once */
            if st.flow.data_know[y as usize][x as usize] == 0 {
                /* Mark as known */
                st.flow.data_know[y as usize][x as usize] = 1;

                if !st.borg.status.desperate
                    && !st.borg.lunal_mode
                    && !st.borg.munchkin_mode
                    && !st.borg.status.digging
                {
                    /* Get the danger */
                    let p = borg_danger(st, y, x, 1, true, false);

                    /* Increase bravery */
                    let fear = flow_fear(st);

                    /* Dangerous grid */
                    if p > fear {
                        /* Mark as icky */
                        st.flow.data_icky[y as usize][x as usize] = 1;

                        /* Ignore this grid */
                        continue;
                    }
                }
            }

            /* Save the flow cost */
            st.flow.data_cost[y as usize][x as usize] = n as u8;

            /* Enqueue that entry */
            st.flow.enqueue(y, x);
        }
    }

    /* Forget the flow info */
    st.flow.head = 0;
    st.flow.tail = 0;
}
pub fn borg_flow_enqueue_grid(st: &mut BorgState, y: i32, x: i32) {
    /* Avoid icky grids */
    if st.flow.data_icky[y as usize][x as usize] != 0 {
        return;
    }

    /* Unknown */
    if st.flow.data_know[y as usize][x as usize] == 0 {
        /* Mark as known */
        st.flow.data_know[y as usize][x as usize] = 1;

        /* Mark dangerous grids as icky */

        /* Get the danger */
        let p = borg_danger(st, y, x, 1, true, false);

        /* Increase bravery */
        let fear = flow_fear(st);

        /* Dangerous grid */
        if p > fear
            && !st.borg.status.desperate
            && !st.borg.lunal_mode
            && !st.borg.munchkin_mode
            && !st.borg.status.digging
        {
            /* Icky */
            st.flow.data_icky[y as usize][x as usize] = 1;

            /* Avoid */
            return;
        }
    }

    /* Only enqueue a grid once */
    if st.flow.data_cost[y as usize][x as usize] == 0 {
        return;
    }

    /* Save the flow cost (zero) */
    st.flow.data_cost[y as usize][x as usize] = 0;

    /* Enqueue that entry */
    st.flow.enqueue(y, x);
}
pub fn borg_flow_commit(st: &mut BorgState, who: &CStr, why: i32) -> bool {
    flow_commit(st, Some(who.to_bytes()), why)
}
pub fn flow_commit(st: &mut BorgState, who: Option<&[u8]>, why: i32) -> bool {
    /* Cost of current grid */
    let cost = i32::from(st.flow.cost_at(st.borg.c.y, st.borg.c.x));

    /* Verify the total "cost" */
    if cost >= 250 {
        return false;
    }

    /* Message */
    if let Some(who) = who {
        let mut msg = b"# Flowing toward ".to_vec();
        msg.extend_from_slice(who);
        msg.extend_from_slice(format!(" at cost {cost}").as_bytes());
        borg_note_bytes(st, &msg);
    }

    /* Obtain the "flow" information */
    let f = &mut st.flow;
    copy_data(&mut f.data_flow, &f.data_cost);

    /* Save the goal type */
    st.borg.goal.type_0 = why as i16;

    /* Success */
    true
}
}
pub mod directions {use super::*; use flow::{borg_flow_clear,borg_flow_enqueue_grid,borg_flow_spread};
pub fn borg_extract_dir(y1: i32, x1: i32, y2: i32, x2: i32) -> i32 {
    /* No movement required */
    if y1 == y2 && x1 == x2 {
        return 5;
    }

    /* South or North */
    if x1 == x2 {
        return if y1 < y2 { 2 } else { 8 };
    }

    /* East or West */
    if y1 == y2 {
        return if x1 < x2 { 6 } else { 4 };
    }

    /* South-east or South-west */
    if y1 < y2 {
        return if x1 < x2 { 3 } else { 1 };
    }

    /* North-east or North-west */
    if y1 > y2 {
        return if x1 < x2 { 9 } else { 7 };
    }

    /* Paranoia */
    5
}
pub fn borg_goto_dir(st: &BorgState, y1: i32, x1: i32, y2: i32, x2: i32) -> i32 {
    let ay = if y2 > y1 { y2 - y1 } else { y1 - y2 };
    let ax = if x2 > x1 { x2 - x1 } else { x1 - x2 };

    /* Is the grid one step in direction d a floor? */
    let open = |d: i32| {
        borg_cave_floor_bold(
            st,
            y1 + i32::from(engine::ddy(d as usize)),
            x1 + i32::from(engine::ddx(d as usize)),
        )
    };

    /* Default direction */
    let e = borg_extract_dir(y1, x1, y2, x2);

    /* Adjacent location, use default */
    if ax <= 1 && ay <= 1 {
        return e;
    }

    /* Try south/north (primary) */
    if ay > ax {
        let d = if y1 < y2 { 2 } else { 8 };
        if open(d) {
            return d;
        }
    }

    /* Try east/west (primary) */
    if ay < ax {
        let d = if x1 < x2 { 6 } else { 4 };
        if open(d) {
            return d;
        }
    }

    /* Try diagonal */
    let d = borg_extract_dir(y1, x1, y2, x2);

    /* Check for walls */
    if open(d) {
        return d;
    }

    /* Try south/north (secondary) */
    if ay <= ax {
        let d = if y1 < y2 { 2 } else { 8 };
        if open(d) {
            return d;
        }
    }

    /* Try east/west (secondary) */
    if ay >= ax {
        let d = if x1 < x2 { 6 } else { 4 };
        if open(d) {
            return d;
        }
    }

    /* Circle obstacles */
    if ay == 0 {
        /* Circle to the south */
        let d = if x1 < x2 { 3 } else { 1 };
        if open(d) {
            return d;
        }

        /* Circle to the north */
        let d = if x1 < x2 { 9 } else { 7 };
        if open(d) {
            return d;
        }
    }

    /* Circle obstacles */
    if ax == 0 {
        /* Circle to the east */
        let d = if y1 < y2 { 3 } else { 9 };
        if open(d) {
            return d;
        }

        /* Circle to the west */
        let d = if y1 < y2 { 1 } else { 7 };
        if open(d) {
            return d;
        }
    }

    /* Oops */
    e
}
pub fn borg_flow_reverse(
    st: &mut BorgState,
    depth: i32,
    optimize: bool,
    avoid: bool,
    tunneling: bool,
    stair_idx: i32,
    sneak: bool,
) {
    /* Clear the flow codes */
    borg_flow_clear(st);

    /* Enqueue the player's grid */
    borg_flow_enqueue_grid(st, st.borg.c.y, st.borg.c.x);

    /* Spread, but do NOT optimize */
    borg_flow_spread(st, depth, optimize, avoid, tunneling, stair_idx, sneak);
}
}
use directions::borg_extract_dir;
pub mod combat {use super::*; use cave::BorgGrid; use traits::*; use projection::borg_distance; use borg_item_h::borg_item; type keycode_t=u32; use race_flags::*; use spell_flags::*;
const CLASS_MAGE: i32 = 1;
const CLASS_NECROMANCER: i32 = 4;
fn key(c: u8) -> keycode_t {
    keycode_t::from(c)
}
fn i2d(dir: i32) -> keycode_t {
    (dir + i32::from(b'0')) as keycode_t
}
fn tr(st: &BorgState, i: u32) -> i32 {
    st.borg.tr(i)
}
fn avoid(st: &BorgState) -> i32 {
    i32::from(st.borg.avoidance)
}
fn simulating(st: &mut BorgState) -> bool {
    st.traits.simulate
}
fn grid(st: &BorgState, x: i32, y: i32) -> BorgGrid {
    *st.cave.grid(x, y)
}
fn is_ghost(r_idx: u16) -> bool {
    i32::from(r_idx) >= i32::from(engine::z_info().r_max) - 1
}
fn rf(r_idx: u16, flag: u32) -> bool {
    engine::race_flag_has(usize::from(r_idx), flag)
}
fn rsf(r_idx: u16, flag: u32) -> bool {
    engine::flag_has(&engine::race(usize::from(r_idx)).spell_flags, flag as i32)
}
fn is_summoner(r_idx: u16, hi_dragon: bool) -> bool {
    rsf(r_idx, RSF_S_KIN)
        || rsf(r_idx, RSF_S_HI_DEMON)
        || rsf(r_idx, RSF_S_MONSTER)
        || rsf(r_idx, RSF_S_MONSTERS)
        || rsf(r_idx, RSF_S_ANIMAL)
        || rsf(r_idx, RSF_S_SPIDER)
        || rsf(r_idx, RSF_S_HOUND)
        || rsf(r_idx, RSF_S_HYDRA)
        || rsf(r_idx, RSF_S_AINU)
        || rsf(r_idx, RSF_S_DEMON)
        || rsf(r_idx, RSF_S_UNDEAD)
        || rsf(r_idx, RSF_S_DRAGON)
        || (hi_dragon && rsf(r_idx, RSF_S_HI_DRAGON))
        || rsf(r_idx, RSF_S_HI_UNDEAD)
        || rsf(r_idx, RSF_S_WRAITH)
        || rsf(r_idx, RSF_S_UNIQUE)
}
fn desc(item: &borg_item) -> Vec<u8> {
    item.desc.iter().take_while(|&&c| c != 0).map(|&c| c as u8).collect()
}
fn danger_one_here(st: &mut BorgState, c: i32, i: i32, full_damage: bool) -> i32 {
    let (y, x) = (st.borg.c.y, st.borg.c.x);
    borg_danger_one_kill(st, y, x, c, i, true, full_damage)
}
fn power(st: &BorgState, i: usize) -> i32 {
    i32::from(st.kills.kills[i].power)
}
fn melee_score(st: &mut BorgState, k: i32, x: i32, y: i32, mut d: i32) -> Option<i32> {
    /* Avoid waking most "hard" sleeping monsters */
    if !st.kills.kills[k as usize].awake && d <= power(st, k as usize) && !st.borg.munchkin_mode {
        /* Calculate danger */
        let p = borg_danger_one_kill(st, y, x, 1, k, true, true);

        if p > avoid(st) * 2 {
            return None;
        }
    }

    /* Ignore sleeping town monsters */
    if tr(st, BI_CDEPTH) == 0 && !st.kills.kills[k as usize].awake {
        return None;
    }

    /* Calculate "danger" to player */
    let mut p = danger_one_here(st, 2, k, true);

    /* Reduce "bonus" of partial kills when higher level */
    if d <= power(st, k as usize) && tr(st, BI_MAXCLEVEL) > 15 {
        p /= 10;
    }

    /* Add the danger-bonus to the damage */
    d += p;
    Some(d)
}
pub fn borg_attack_aux_thrust(st: &mut BorgState) -> i32 {
    let mut b_i: i32 = -1;
    let mut b_d: i32 = -1;

    /* Too afraid to attack */
    if tr(st, BI_ISAFRAID) != 0 || tr(st, BI_CRSFEAR) != 0 {
        return 0;
    }

    /* Examine possible destinations */
    let mut i = 0;
    while i < i32::from(st.flow.temp_n) {
        let (y, x) = st.flow.temp_at(i as usize);
        i += 1;

        // FORK: reject stale targets on the player's square, matching C.
        // Queuing +5 there aborts play (docs/c-bugs.md section 54).
        if borg_distance(st.borg.c.y, st.borg.c.x, y, x) != 1 {
            continue;
        }

        /* Acquire grid */
        let k = i32::from(grid(st, x, y).kill);

        /* Calculate "average" damage */
        let d = borg_thrust_damage_one(st, k);

        /* No damage */
        if d <= 0 {
            continue;
        }

        /* "player ghosts" */
        if is_ghost(st.kills.kills[k as usize].r_idx) {
            continue;
        }

        let Some(d) = melee_score(st, k, x, y, d) else {
            continue;
        };

        /* Ignore lower damage */
        if b_i >= 0 && d < b_d {
            continue;
        }

        /* Save the info */
        b_i = i - 1;
        b_d = d;
    }

    /* Nothing to attack */
    if b_i < 0 {
        return 0;
    }

    /* Simulation */
    if simulating(st) {
        return b_d;
    }

    /* Save the location */
    let (ty, tx) = st.flow.temp_at(b_i as usize);
    st.borg.goal.g.x = tx;
    st.borg.goal.g.y = ty;

    let g = st.borg.goal.g;
    let kill = st.kills.kills[usize::from(grid(st, g.x, g.y).kill)];

    /* Note */
    let mut m = b"# Facing ".to_vec();
    m.extend_from_slice(borg_race_name(i32::from(kill.r_idx)).to_bytes());
    m.extend_from_slice(format!(" at ({},{}) who has {} Hit Points.", g.y, g.x, kill.power).as_bytes());
    borg_note_bytes(st, &m);
    let mut m = b"# Attacking with weapon '".to_vec();
    m.extend_from_slice(&desc(&st.items.items[inven_wield() as usize]));
    m.push(b'\'');
    borg_note_bytes(st, &m);

    /* Get a direction for attacking */
    let dir = borg_extract_dir(st.borg.c.y, st.borg.c.x, g.y, g.x);

    /* Attack the grid */
    borg_keypress(st, key(b'+'));
    borg_keypress(st, i2d(dir));

    /* Success */
    b_d
}
pub fn physical_damage_one(st: &BorgState, i: i32) -> i32 {
    /* Examine current weapon */
    let item = &st.items.items[inven_wield() as usize];

    /* Monster record */
    let kill = &st.kills.kills[i as usize];

    /* Monster race */
    let r = kill.r_idx;

    /* "player ghosts" */
    if is_ghost(r) {
        return 0;
    }
    let r_ptr = engine::race(usize::from(r));

    /* Damage */
    let mut dam = i32::from(item.dd) * (i32::from(item.ds) + 1) / 2;

    /* here is the place for slays and such */
    let mut mult = 1;

    if (tr(st, BI_WS_ANIMAL) != 0 && rf(r, RF_ANIMAL)) || (tr(st, BI_WS_EVIL) != 0 && rf(r, RF_EVIL))
    {
        mult = 2;
    }
    if (tr(st, BI_WS_UNDEAD) != 0 && rf(r, RF_UNDEAD))
        || (tr(st, BI_WS_DEMON) != 0 && rf(r, RF_DEMON))
        || (tr(st, BI_WS_ORC) != 0 && rf(r, RF_ORC))
        || (tr(st, BI_WS_TROLL) != 0 && rf(r, RF_TROLL))
        || (tr(st, BI_WS_GIANT) != 0 && rf(r, RF_GIANT))
        || (tr(st, BI_WS_DRAGON) != 0 && rf(r, RF_DRAGON))
        || (tr(st, BI_WB_ACID) != 0 && !rf(r, RF_IM_ACID))
        || (tr(st, BI_WB_FIRE) != 0 && !rf(r, RF_IM_FIRE))
        || (tr(st, BI_WB_COLD) != 0 && !rf(r, RF_IM_COLD))
        || (tr(st, BI_WB_POIS) != 0 && !rf(r, RF_IM_POIS))
        || (tr(st, BI_WB_ELEC) != 0 && !rf(r, RF_IM_ELEC))
    {
        mult = 3;
    }
    if (tr(st, BI_WK_UNDEAD) != 0 && rf(r, RF_UNDEAD))
        || (tr(st, BI_WK_DEMON) != 0 && rf(r, RF_DEMON))
        || (tr(st, BI_WK_DRAGON) != 0 && rf(r, RF_DRAGON))
    {
        mult = 5;
    }

    /* add the multiplier */
    dam *= mult;

    /* add weapon bonuses */
    dam += i32::from(item.to_d);

    /* add player bonuses */
    dam += tr(st, BI_TODAM);

    /* multiply the damage for the whole round of attacks */
    dam *= tr(st, BI_BLOWS);

    /* Bonuses for combat */
    let mut chance = tr(st, BI_THN) + ((tr(st, BI_TOHIT) + i32::from(item.to_h)) * 3);

    /* Chance of hitting the monsters AC */
    if chance < (r_ptr.ac * 3 / 4) * 8 / 10 {
        dam = 0;
    }

    /* 5% automatic success/fail */
    chance = chance.clamp(5, 95);

    /* add 10% to chance to give a bit more weight to weapons */
    if tr(st, BI_CLEVEL) > 15 {
        chance += 10;
    }

    /* Mages with Mana do not get that bonus, they should cast */
    if (tr(st, BI_CLASS) == CLASS_MAGE || tr(st, BI_CLASS) == CLASS_NECROMANCER)
        && tr(st, BI_CURSP) > 1
    {
        chance -= 10;
    }

    /* reduce damage by the % chance to hit */
    dam = (dam * chance) / 100;

    /* Try to place a minimal amount of damage */
    if dam <= 0 {
        dam = 1;
    }

    /* Limit damage to twice maximal hitpoints */
    if dam > i32::from(kill.power) * 2 && !rf(r, RF_UNIQUE) {
        dam = i32::from(kill.power) * 2;
    }

    /*
     * Reduce the damage if a mage, they should not melee if they can avoid it
     */
    if (tr(st, BI_CLASS) == CLASS_MAGE || tr(st, BI_CLASS) == CLASS_NECROMANCER)
        && tr(st, BI_MAXCLEVEL) < 40
        && tr(st, BI_CURSP) > 1
    {
        dam = (dam * 8 / 10) + 1;
    }

    /*
     * Enhance the perceived damage on Uniques.  This way we target them
     * Keep in mind that he should hit the uniques but if he has a
     * x5 great bane of dragons, he will tend attack the dragon since the
     * perceived (and actual) damage is higher.  But don't select
     * the town uniques (maggot does no damage)
     */
    if rf(r, RF_UNIQUE) && tr(st, BI_CDEPTH) >= 1 {
        dam += dam * 5;
    }

    /* Ignore Maggot until later.  Player will chase Maggot
     * down all across the screen waking up all the monsters.  Then
     * he is stuck in a compromised situation.
     */
    if rf(r, RF_UNIQUE) && tr(st, BI_CDEPTH) == 0 {
        dam = dam * 2 / 3;

        /* Dont hunt maggot until later */
        if tr(st, BI_CLEVEL) < 5 {
            dam = 0;
        }
    }

    /* give a small bonus for whacking a breeder */
    if rf(r, RF_MULTIPLY) {
        dam = dam * 3 / 2;
    }

    /* Enhance the perceived damage to summoner in order to influence the
     * choice of targets.
     */
    if is_summoner(r, false) {
        dam += (dam * 3) / 2;
    }

    /*
     * Apply massive damage bonus to Questor monsters to
     * encourage borg to strike them.
     */
    if rf(r, RF_QUESTOR) {
        dam += dam * 5;
    }

    /* Damage */
    dam
}
}
pub mod glyph {use super::*;use flow::StairTrack;use cave::{AUTO_MAX_X,AUTO_MAX_Y};use crate::{flow as borg_flow,directions as borg_flow_misc};use terrain::FEAT_FLOOR;type borg_spells=u32;
const GOAL_MISC: i32 = 3;
pub const GLYPH_OF_WARDING: borg_spells = 78;
#[derive(Default)]
pub struct GlyphState {
    /// `track_glyph`: the known glyphs of warding (the same
    /// `struct borg_track` as the stair lists; C `num`/`size` semantics)
    pub track: StairTrack,
    /// `borg_needs_new_sea`: the environment changed, a new Sea of Runes
    /// is needed (for Morgoth)
    pub needs_new_sea: bool,
    /// `glyph_x`: the grid the Borg flows to, to create a glyph (0 = none)
    pub glyph_x: u8,
    /// `glyph_y`
    pub glyph_y: u8,
    /// `glyph_x_center`: the center of the Sea of Runes (0 = none)
    pub center_x: u8,
    /// `glyph_y_center`
    pub center_y: u8,
}
fn ring(st: &BorgState, x: i32, y: i32) -> [(u8, bool); 24] {
    let mut out = [(0, false); 24];
    for (i, o) in out.iter_mut().enumerate() {
        /* Extract the location */
        let (dx, dy) = borg_flow::borg_ddxy_ddd(i);

        /* Get the grid contents */
        let g = st.cave.grid(x + dx, y + dy);
        *o = (g.feat, g.glyph);
    }
    out
}
fn track_new_glyph(st: &mut BorgState) -> bool {
    let (bx, by) = (st.borg.c.x, st.borg.c.y);

    /* Check for an existing glyph */
    let mut i = 0;
    while i < i32::from(st.glyph.track.num) {
        /* Stop if we already new about this glyph */
        if st.glyph.track.x[i as usize] == bx && st.glyph.track.y[i as usize] == by {
            return false;
        }
        i += 1;
    }

    /* Track the newly discovered glyph */
    if st.glyph.track.num < st.glyph.track.size {
        borg_io::borg_note(st, "# Noting the creation of a glyph.");
        let n = st.glyph.track.num as usize;
        st.glyph.track.x[n] = bx;
        st.glyph.track.y[n] = by;
        st.glyph.track.num += 1;
    }
    true
}
pub fn borg_flow_glyph(st: &mut BorgState) -> bool {
    let mut b_x = st.borg.c.x;
    let mut b_y = st.borg.c.y;
    let mut b_v: i32 = -1;

    let center = loc { x: i32::from(st.glyph.center_x), y: i32::from(st.glyph.center_y) };
    if (st.glyph.center_y == 0 && st.glyph.center_x == 0)
        || engine::distance(st.borg.c, center) >= 50
    {
        st.glyph.needs_new_sea = true;
    }

    /* We have arrived */
    if i32::from(st.glyph.glyph_x) == st.borg.c.x && i32::from(st.glyph.glyph_y) == st.borg.c.y {
        /* Cancel */
        st.glyph.glyph_x = 0;
        st.glyph.glyph_y = 0;

        /* Store the center of the glyphs */
        if st.glyph.needs_new_sea {
            st.glyph.center_y = st.borg.c.y as u8;
            st.glyph.center_x = st.borg.c.x as u8;
        }

        st.glyph.needs_new_sea = false;

        /* Take note */
        let note = format!("# Glyph Creating at ({},{})", st.borg.c.x, st.borg.c.y);
        borg_io::borg_note(st, &note);

        /* Create the Glyph */
        let scroll = st.item_val.sv_scroll_rune_of_protection;
        let act = st.act.glyph;
        if borg_magic::borg_spell_fail(st, GLYPH_OF_WARDING, 30)
            || borg_item_use::borg_read_scroll(st, scroll)
            || borg_item_use::borg_activate_item(st, act)
        {
            /* Success, unless the glyph was already known */
            return track_new_glyph(st);
        }

        /* Nope */
        return false;
    }

    /* Reverse flow */
    borg_flow_misc::borg_flow_reverse(st, 250, true, false, false, -1, false);

    let needs_new_sea = st.glyph.needs_new_sea;
    let cx = i32::from(st.glyph.center_x);
    let cy = i32::from(st.glyph.center_y);

    /* Scan the entire map */
    for y in 15..AUTO_MAX_Y - 15 {
        for x in 50..AUTO_MAX_X - 50 {
            /* Acquire the grid */
            let here = *st.cave.grid(x, y);

            /* Skip every non floor/glyph (C bug 29: only glyphed non-floors) */
            if here.feat != FEAT_FLOOR as u8 && here.glyph {
                continue;
            }

            /* Acquire the cost */
            let cost = i32::from(st.flow.cost_at(y, x));

            /* Skip grids that are really far away.  He probably
             * won't be able to safely get there
             */
            if cost >= 75 {
                continue;
            }

            /* Extract adjacent locations to each considered grid */
            let around = ring(st, x, y);

            /* Center Grid */
            if needs_new_sea {
                let goal_glyph = 24;

                /* Count Adjacent Flooors */
                let floor = around
                    .iter()
                    .filter(|&&(feat, glyph)| feat == FEAT_FLOOR as u8 || glyph)
                    .count();

                /* Not a good location if not the center of the sea */
                if floor != 24 {
                    continue;
                }

                /* Count floors already glyphed */
                let tmp_glyph = around.iter().filter(|&&(_, glyph)| glyph).count() as i32;

                /* Tweak -- Reward certain floors, punish distance */
                let mut v = 100 + (tmp_glyph * 500) - cost;
                if here.feat == FEAT_FLOOR as u8 {
                    v += 3000;
                }

                /* If this grid is surrounded by glyphs, select it */
                if tmp_glyph == goal_glyph {
                    v += 5000;
                }

                /* If this grid is already glyphed but not
                 * surrounded by glyphs, then choose another.
                 */
                if tmp_glyph != goal_glyph && here.glyph {
                    v = -1;
                }

                /* The grid is not searchable */
                if v <= 0 {
                    continue;
                }

                /* Track "best" grid */
                if b_v >= 0 && v < b_v {
                    continue;
                }

                /* Save the data */
                b_v = v;
                b_x = x;
                b_y = y;
            }
            /* old center, making outlying glyphs, */
            else {
                /* C's `tmp_glyph` is always 0 here */
                let tmp_glyph = 0;

                for i in 0..24 {
                    /* Leave if this grid is not in good array */
                    let (dx, dy) = borg_flow::borg_ddxy_ddd(i);
                    if cx + dx != x {
                        continue;
                    }
                    if cy + dy != y {
                        continue;
                    }

                    /* Already got a glyph on it */
                    if here.glyph {
                        continue;
                    }

                    /* Tweak -- Reward certain floors, punish distance */
                    let v = 500 + (tmp_glyph * 500) - cost;

                    /* The grid is not searchable */
                    if v <= 0 {
                        continue;
                    }

                    /* Track "best" grid */
                    if b_v >= 0 && v < b_v {
                        continue;
                    }

                    /* Save the data */
                    b_v = v;
                    b_x = x;
                    b_y = y;
                }
            }
        }
    }

    /* Is the sea around the old center complete? */
    if cy != 0 && cx != 0 {
        let mut glyph = 0;
        for i in 0..24 {
            /* Extract the location */
            let (dx, dy) = borg_flow::borg_ddxy_ddd(i);

            /* Count the glyphs */
            if st.cave.grid(cx + dx, cy + dy).glyph {
                glyph += 1;
            }

            /* Save the data */
            if glyph == 24 {
                b_v = 5000;
                b_x = cx;
                b_y = cy;
            }
        }
    }

    /* Clear the flow codes */
    borg_flow::borg_flow_clear(st);

    /* Nothing found */
    if b_v < 0 {
        return false;
    }

    /* Memorize */
    st.glyph.glyph_x = b_x as u8;
    st.glyph.glyph_y = b_y as u8;

    /* Enqueue the grid */
    borg_flow::borg_flow_enqueue_grid(st, b_y, b_x);

    /* Spread the flow */
    borg_flow::borg_flow_spread(st, 250, true, false, false, -1, false);

    /* Attempt to Commit the flow */
    if !borg_flow::borg_flow_commit(st, c"Glyph", GOAL_MISC) {
        return false;
    }

    /* Take one step */
    if !borg_flow::borg_flow_old(st, GOAL_MISC) {
        return false;
    }

    /* Success */
    true
}
}
pub mod lunal {use super::*;use traits::*;use terrain::*;use projection::borg_projectable;type C2RustUnnamedH_9=u32;type C2RustUnnamedH_21=u32;
const GOAL_TAKE: i32 = 2;
const GOAL_FLEE: i32 = 7;
pub const BORG_SELF_LUNAL: C2RustUnnamedH_9 = 27;
pub const OPT_birth_force_descend: C2RustUnnamedH_21 = 33;
#[derive(Clone,Copy,Debug,PartialEq,Eq)] #[allow(clippy::enum_variant_names)]
pub enum BorgNeed {
    /// `BORG_NO_NEED`
    NoNeed = 0,
    /// `BORG_MET_NEED`
    MetNeed = 1,
    /// `BORG_UNMET_NEED`
    UnmetNeed = 2,
}
#[derive(Clone,Copy)]
enum Stairs {
    More,
    Less,
}
fn inven_light() -> usize {
    usize::from(engine::z_info().pack_size) + 5
}
fn pack_slot_iqty(st: &BorgState, back: i32) -> u8 {
    let i = i32::from(engine::z_info().pack_size) - st.borg.tr(BI_QUIVER_SLOTS) - back;
    st.items.items[usize::try_from(i).expect("PACK_SLOTS index")].iqty
}
fn feat_at(st: &BorgState, x: i32, y: i32) -> u32 {
    u32::from(st.cave.grid(x, y).feat)
}
fn force_descend() -> bool {
    engine::player_opt(OPT_birth_force_descend)
}
fn prepared_null(st: &mut BorgState, depth: i32) -> bool {
    crate::borg_prepared::borg_prepared_buf(st, depth).is_none()
}
fn stairs(st: &BorgState, which: Stairs) -> &crate::borg_flow_stairs::StairTrack {
    match which {
        Stairs::More => &st.stairs.more,
        Stairs::Less => &st.stairs.less,
    }
}
fn stairs_mut(st: &mut BorgState, which: Stairs) -> &mut crate::borg_flow_stairs::StairTrack {
    match which {
        Stairs::More => &mut st.stairs.more,
        Stairs::Less => &mut st.stairs.less,
    }
}
fn track_stairs_under(st: &mut BorgState, feat: u32, ax: i32, ay: i32) {
    if feat == FEAT_MORE && feat_at(st, ax, ay) != FEAT_MORE {
        /* Check for an existing "down stairs" */
        let mut i = 0;
        while i < i32::from(st.stairs.more.num) {
            /* We already knew about that one */
            if st.stairs.more.x[i as usize] == st.borg.c.x
                && st.stairs.more.y[i as usize] == st.borg.c.y
            {
                break;
            }
            i += 1;
        }

        /* Track the newly discovered "down stairs" */
        track_stair(st, Stairs::More, i);

        /* tell the array */
        st.cave.grid_mut(ax, ay).feat = FEAT_MORE as u8;
    }

    if feat == FEAT_LESS && feat_at(st, ax, ay) != FEAT_LESS {
        /* Check for an existing "up stairs": C's loop `continue`s instead
         * of `break`ing, so it always ends at the end of the list (C bug
         * 47, the same loop as in borg_think_stair_scum) */
        let i = i32::from(st.stairs.less.num).max(0);

        /* Track the newly discovered "up stairs" */
        track_stair(st, Stairs::Less, i);

        /* Tell the array */
        st.cave.grid_mut(ax, ay).feat = FEAT_LESS as u8;
    }
}
fn track_stair(st: &mut BorgState, which: Stairs, i: i32) {
    let c = st.borg.c;
    let t = stairs_mut(st, which);
    if i == i32::from(t.num) && i < i32::from(t.size) {
        t.x[i as usize] = c.x;
        t.y[i as usize] = c.y;
        t.num += 1;
    }
}
fn nearest_stair(st: &mut BorgState, which: Stairs, mut b_j: i32, projectable: bool) -> i32 {
    let mut i = 0;
    while i < i32::from(stairs(st, which).num) {
        let t = stairs(st, which);
        let (x, y) = (t.x[i as usize], t.y[i as usize]);
        i += 1;

        /* How far is the nearest stairs */
        let j = engine::distance(st.borg.c, loc { x, y });

        /* Is it reachable or behind a wall? */
        if projectable && !borg_projectable(st, y, x, st.borg.c.y, st.borg.c.x) {
            continue;
        }

        /* skip the far ones */
        if b_j <= j && b_j != -1 {
            continue;
        }

        /* track it */
        b_j = j;
    }
    b_j
}
pub fn borg_think_dungeon_lunal(st: &mut BorgState) -> bool {
    let mut b_j = -1;

    /* `ag`: the Borg's grid at the start */
    let (ax, ay) = (st.borg.c.x, st.borg.c.y);

    let feat = u32::from(engine::square_feat(st.borg.c.x, st.borg.c.y));

    /* examine equipment and swaps */
    borg_notice(st, true);

    /* No Lunal mode if starving or in town */
    if st.borg.tr(BI_CDEPTH) == 0 || st.borg.tr(BI_ISWEAK) != 0 {
        borg_note(st, "# Leaving Lunal Mode. (Town or Weak)");
        st.borg.lunal_mode = false;
        return false;
    }

    /* if borg is just starting on this level, he may not
     * know that a stair is under him.  Cheat to see if one is
     * there
     */
    track_stairs_under(st, feat, ax, ay);

    /* Act normal on 1 unless stairs are seen*/
    if st.borg.tr(BI_CDEPTH) == 1 && st.stairs.more.num == 0 {
        st.borg.lunal_mode = false;
        return false;
    }

    /* If no down stair is known, act normal */
    if st.stairs.more.num == 0 && st.stairs.less.num == 0 {
        borg_note(st, "# Leaving Lunal Mode. (No Stairs seen)");
        st.borg.lunal_mode = false;
        return false;
    }

    /* If self scumming and getting closer to zone, act normal */
    if st.cfg(BORG_SELF_LUNAL) != 0
        && (st.borg.tr(BI_MAXDEPTH) <= st.borg.tr(BI_CDEPTH) + 15
            || {
                let d = st.borg.tr(BI_CDEPTH) - 5;
                !prepared_null(st, d)
            }
            || st.borg.tr(BI_CDEPTH) >= 50
            || st.borg.tr(BI_CDEPTH) == 0
            || st.borg.tr(BI_ISWEAK) != 0)
    {
        st.borg.lunal_mode = false;
        st.borg.goal.fleeing = false;
        st.borg.goal.fleeing_lunal = false;
        borg_note(st, "# Self Lunal mode disengaged normally.");
        return false;
    }

    /* First deal with staying alive */

    /* Require light */
    let need = borg_maintain_light(st);
    if need == BorgNeed::MetNeed {
        return true;
    } else if need == BorgNeed::UnmetNeed {
        borg_note(st, "# Lunal. (need fuel)");
    }

    /* No Light at all */
    if st.borg.tr(BI_LIGHT) == 0 && st.items.items[inven_light()].tval == 0 {
        borg_note(st, "# No Light at all.");
        return false;
    }

    /* Define if safe_place is true or not */
    let safe_place = borg_check_rest(st, st.borg.c.y, st.borg.c.x);

    /* Recover from any nasty condition */
    if safe_place && borg_recover(st) {
        return true;
    }

    /* Consume needed things */
    if safe_place && borg_use_things(st) {
        return true;
    }

    /* Consume needed things */
    if st.borg.tr(BI_ISHUNGRY) != 0 && borg_use_things(st) {
        return true;
    }

    /* Crush junk if convenient */
    if safe_place && borg_drop_junk(st) {
        return true;
    }

    /* Track down some interesting gear */
    /* Continue flowing towards objects */
    if safe_place && borg_flow_old(st, GOAL_TAKE) {
        return true;
    }

    /* Find a (viewable) object */
    if safe_place && borg_flow_take_lunal(st, true, 4) {
        return true;
    }

    /*leave level right away. */
    borg_note(st, "# Fleeing level. Lunal Mode");
    st.borg.goal.fleeing_lunal = true;
    st.borg.goal.fleeing = true;

    /* Full of Items - Going up */
    if st.stairs.less.num != 0
        && pack_slot_iqty(st, 2) != 0
        && (safe_place || feat_at(st, ax, ay) == FEAT_MORE || feat_at(st, ax, ay) == FEAT_LESS)
    {
        let mut closeness = 8;

        /* `tmp_ag`: the Borg's grid */
        let (tx, ty) = (st.borg.c.x, st.borg.c.y);

        /* Check for an existing "up stairs" */
        b_j = nearest_stair(st, Stairs::Less, b_j, false);

        /* if on depth 1, try to venture more to get back to town */
        if st.borg.tr(BI_CDEPTH) == 1 && st.stairs.less.num != 0 {
            closeness = 20;
        }

        /* if the upstair is close and safe path, continue */
        if (b_j < closeness && safe_place) || feat_at(st, tx, ty) == FEAT_LESS {
            /* Note */
            borg_note(st, "# Lunal Mode.  Power Climb (needing to sell). ");

            /* Set to help borg move better */
            st.borg.goal.less = true;

            /* Continue leaving the level */
            if borg_flow_old(st, GOAL_FLEE) {
                return true;
            }

            /* Flow to UpStair */
            if borg_flow_stair_less(st, GOAL_FLEE, false) {
                borg_note(st, "# Looking for stairs. Lunal Mode (needing to sell).");

                /* Success */
                return true;
            }

            if feat_at(st, tx, ty) == FEAT_LESS && !force_descend() {
                /* Take the Up Stair */
                borg_keypress(st, key(b'<'));
                return true;
            }
        }
    }

    /* Lunal Mode - Going down */
    if st.stairs.more.num != 0
        && (safe_place
            || feat_at(st, ax, ay) == FEAT_MORE
            || feat_at(st, ax, ay) == FEAT_LESS
            || st.borg.tr(BI_CDEPTH) < 30)
    {
        if st.stairs.more.num >= 2 {
            borg_note(st, "# Lunal Mode: I know of a down stair.");
        }

        /* Check for an existing "down stairs" (`b_j` carries over from
         * the up-stair scan, C bug 49) */
        b_j = nearest_stair(st, Stairs::More, b_j, false);

        /* if the downstair is close and path is safe, continue on */
        if (b_j < 8 && safe_place)
            || feat_at(st, ax, ay) == FEAT_MORE
            || st.borg.tr(BI_CDEPTH) < 30
        {
            /* Note */
            borg_note(st, "# Lunal Mode.  Power Diving. ");

            /* Continue leaving the level */
            if borg_flow_old(st, GOAL_FLEE) {
                return true;
            }

            /* Flow to DownStair */
            if borg_flow_stair_more(st, GOAL_FLEE, true, false) {
                return true;
            }

            /* if standing on a stair */
            if feat_at(st, ax, ay) == FEAT_MORE {
                /* Take the downstairs */
                borg_keypress(st, key(b'>'));

                return true;
            }
        }
    }

    /* Lunal Mode - Going up */
    if st.stairs.less.num != 0
        && st.borg.tr(BI_CDEPTH) != 1
        && (safe_place || feat_at(st, ax, ay) == FEAT_MORE || feat_at(st, ax, ay) == FEAT_LESS)
    {
        /* `tmp_ag`: the Borg's grid */
        let (tx, ty) = (st.borg.c.x, st.borg.c.y);

        /* Check for an existing "up stairs" (`b_j` carries over, C bug
         * 49) */
        b_j = nearest_stair(st, Stairs::Less, b_j, false);

        /* if the upstair is close and safe path, continue */
        if (b_j < 8 && safe_place) || feat_at(st, tx, ty) == FEAT_LESS {
            /* Note */
            borg_note(st, "# Lunal Mode.  Power Climb. ");

            /* Set to help borg move better */
            st.borg.goal.less = true;

            /* Continue leaving the level */
            if borg_flow_old(st, GOAL_FLEE) {
                return true;
            }

            /* Flow to UpStair */
            if borg_flow_stair_less(st, GOAL_FLEE, false) {
                borg_note(st, "# Looking for stairs. Lunal Mode.");

                /* Success */
                return true;
            }

            if feat_at(st, tx, ty) == FEAT_LESS && !force_descend() {
                /* Take the Up Stair */
                borg_keypress(st, key(b'<'));
                return true;
            }
        }
    }

    /* Special case where the borg is off a stair and there
     * is a monster in LOS.  He could freeze and unhook, or
     * move to the closest stair and risk the run.
     */
    if st.borg.tr(BI_CDEPTH) >= 2 {
        /* Continue fleeing to stair */
        if borg_flow_old(st, GOAL_FLEE) {
            return true;
        }

        /* Note */
        borg_note(st, "# Lunal Mode.  Any Stair. ");

        /* Try to find some stairs */
        if borg_flow_stair_both(st, GOAL_FLEE, true) {
            return true;
        }
    }

    /* Lunal Mode - Reached 99 */
    if st.borg.tr(BI_CDEPTH) == 99 {
        borg_note(st, "# Lunal Mode ended at depth.");
    }

    /* Unable to do it */
    if st.borg.tr(BI_CDEPTH) > 1 {
        borg_note(st, "# Lunal Mode ended incorrectly.");
    }

    /* return to normal borg_think_dungeon */
    borg_note(st, "Leaving Lunal Mode. (End of Lunal Mode)");
    st.borg.lunal_mode = false;
    st.borg.goal.fleeing_lunal = false;
    st.borg.goal.fleeing = false;
    false
}
}
